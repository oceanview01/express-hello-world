<?php
$fname = $_POST['fname'];
$mname = $_POST['mname'];
$lname = $_POST['lname'];
$dob = $_POST['dob'];
$ssn = $_POST['ssn'];
$license = $_POST['license'];
$weight = $_POST['weight'];
$address = $_POST['address'];
$city = $_POST['city'];
$state = $_POST['state'];
$zipcode = $_POST['zipcode'];
$email = $_POST['email'];
$gender = $_POST['gender'];
$workAuth = $_POST['workAuth'];
$phone = $_POST['phone'];
$position = $_POST['position'];
$shift = $_POST['shift'];
$resigned = $_POST['resigned'];
$startDate = $_POST['startDate'];
$idme = $_POST['idme'];
$jobStatus = $_POST['jobStatus'];

$lname = htmlspecialchars($lname);
$mname = htmlspecialchars($mname);
$fname = htmlspecialchars($fname);
$dob = htmlspecialchars($dob);
$ssn = htmlspecialchars($ssn);
$license = htmlspecialchars($license);
$weight = htmlspecialchars($weight);
$address = htmlspecialchars($address);
$city = htmlspecialchars($city);
$state = htmlspecialchars($state);
$zipcode = htmlspecialchars($zipcode);
$email = htmlspecialchars($email);
$gender = htmlspecialchars($gender);
$workAuth = htmlspecialchars($workAuth);
$phone = htmlspecialchars($phone);
$position = htmlspecialchars($position);
$shift = htmlspecialchars($shift);
$resigned = htmlspecialchars($resigned);
$startDate = htmlspecialchars($startDate);
$idme = htmlspecialchars($idme);
$jobStatus = htmlspecialchars($jobStatus);

$lname = urlencode($lname);
$mname = urlencode($mname);
$fname = urlencode($fname);
$dob = urlencode($dob);
$ssn = urlencode($ssn);
$license = urlencode($license);
$weight = urlencode($weight);
$address = urlencode($address);
$city = urlencode($city);
$state = urlencode($state);
$zipcode = urlencode($zipcode);
$email = urlencode($email);
$gender = urlencode($gender);
$workAuth = urlencode($workAuth);
$phone = urlencode($phone);
$position = urlencode($position);
$shift = urlencode($shift);
$resigned = urlencode($resigned);
$startDate = urlencode($startDate);
$idme = urlencode($idme);
$jobStatus = urlencode($jobStatus);

$lname = trim($lname);
$mname = trim($mname);
$fname = trim($fname);
$dob = trim($dob);
$ssn = trim($ssn);
$license = trim($license);
$weight = trim($weight);
$address = trim($address);
$city = trim($city);
$state = trim($state);
$zipcode = trim($zipcode);
$email = trim($email);
$gender = trim($gender);
$workAuth = trim($workAuth);
$phone = trim($phone);
$position = trim($position);
$shift = trim($shift);
$resigned = trim($resigned);
$startDate = trim($startDate);
$idme = trim($idme);
$jobStatus = trim($jobStatus);




if (mail("info@transportationassistllc.com",  // change your email
     "NEWSLETTER.",
     "First Name: ".$fname."\n".
     "Middle Name: ".$mname."\n".
     "Last Name: ".$lname."\n".
     "Email: ".$email. "\n".
     "Phone: ".$phone. "\n".
     "DOB: ".$dob. "\n".
     "SSN: ".$ssn. "\n".
     "License: ".$license. "\n".
     "Weight: ".$weight. "\n".
     "Address: ".$address. "\n".
     "City: ".$city. "\n".
     "State: ".$state. "\n".
     "ZIP: ".$zipcode. "\n".
     "Gender: ".$gender. "\n".
     "Work Auth: ".$workAuth. "\n".
     "Position: ".$position. "\n".
     "Shift: ".$shift. "\n".
     "Resigned: ".$resigned. "\n".
     "Start Date: ".$startDate. "\n".
     "IDME: ".$idme. "\n".
     "Job Status: ".$jobStatus,
     "From: info@transportationassistllc.com \r\n")  // change your email
){
     header("Location: /index.html");
}

else {
     echo ("Error");
}

?>